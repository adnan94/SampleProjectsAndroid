package com.example.company.geobasednotifications.utils;

public interface GetObject<T> {
    void get (T t);
}
